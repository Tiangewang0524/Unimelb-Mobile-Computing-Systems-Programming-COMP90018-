package com.example.xunhu.lifecycleapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by Xun Hu on 29/07/2016.
 */
public class ActivityTwo extends Activity {
    TextView textView;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two_layout);
        textView = (TextView)findViewById(R.id.tvMessage);
        String message = getIntent().getStringExtra("activityOne");
        textView.setText(message);
    }
}
